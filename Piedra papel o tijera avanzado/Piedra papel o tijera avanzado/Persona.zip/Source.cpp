#include<iostream>
#include<string>
#include"Persona.h"

using namespace std;

int main()
{
	Persona mipersona;
	mipersona.DeterminarGanador();
	return 0;
}